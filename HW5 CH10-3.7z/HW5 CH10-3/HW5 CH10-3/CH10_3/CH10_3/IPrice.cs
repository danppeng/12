﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CH10_3
{
    internal interface IPrice
    {
        double GetPrice();
    }
}
